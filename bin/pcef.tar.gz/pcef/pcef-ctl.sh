#! /bin/bash

SIGNAL=10
WORK_DIR=/tmp/freeDiameter
PROG=`basename $0`

usage() {
    cat <<EOF
Usage: $PROG init|update-input|update-output|dump|reset
EOF
}

PID=`ps aux | grep '[f]reeDiameterd' | awk '{print $2}'`
if [ -z "$PID" ]; then
    echo 'freeDiameterd is not running'
    exit 1
fi

if [ ! -d "$WORK_DIR" ]; then
    mkdir -p $WORK_DIR
fi

rm -f $WORK_DIR/*

case "$1" in
    init)
        touch $WORK_DIR/init
        ;;
    update-input)
        touch $WORK_DIR/update-input
        ;;
    update-output)
        touch $WORK_DIR/update-output
        ;;
    dump)
        touch $WORK_DIR/dump
        ;;
    reset)
        touch $WORK_DIR/reset
        ;;
    *)
        usage
        exit 1
        ;;
esac

kill -$SIGNAL $PID

